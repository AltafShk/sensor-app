import mysql from "mysql2";

export class Database {
  private pool: mysql.Pool;
  private static instance: Database;

  constructor() {
    this.pool = mysql.createPool({
      host: "awseb-e-vfhdt2jkt5-stack-awsebrdsdatabase-9oz55myqmaxc.cdicimuimz8z.us-east-2.rds.amazonaws.com",
      user: "altafshaikh",
      password: "AltShk123...",
      database: "ebdb",
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
    });
  }

  public static getInstance(): Database {
    if (!Database.instance) {
      Database.instance = new Database();
    }

    console.log("Database instance connected");
    return Database.instance;
  }

  async query(sql: string, params: any[] = []): Promise<any> {
    return new Promise((resolve, reject) => {
      this.pool.query(sql, params, (err, results) => {
        if (err) {
          reject(err);
        } else {
          resolve(results);
        }
      });
    });
  }
}
