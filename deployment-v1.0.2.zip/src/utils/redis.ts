import { createClient } from "redis";

export const redisClient = createClient({
  url: "redis://sensor-cache.55uxma.ng.0001.use2.cache.amazonaws.com:6379",
});
