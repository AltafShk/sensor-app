import { Router } from "express";
import { SensorController } from "../controller/sensor.controller";

const SensorRouter = Router();

SensorRouter.post("/", SensorController.handleSignal);

export { SensorRouter };
