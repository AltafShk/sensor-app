import express, { Request, Response } from "express";
import { Database } from "./utils/db";
import { Middlewares } from "./middlewares";
import { SensorRouter } from "./routes/sensor.router";
import { redisClient } from "./utils/redis";

const app = express();

app.use(Middlewares.Json());
app.use(Middlewares.UrlEncoded());

app.get("/", (req, res) => {
  res.status(200).send("OK");
});

app.use("/sensor", SensorRouter);

app.get("/test1", async (req: Request, res: Response) => {
  await redisClient.set("key1", "value1");
  return res.status(200).send("OK");
});

app.get("/test2", async (req: Request, res: Response) => {
  const value = await redisClient.get("key1");
  return res.status(200).send(value);
});

app.use(Middlewares.ErrorHandler());

app.listen(3000, async () => {
  Database.getInstance();
  await redisClient.connect();
  console.log("App listening on port 3000!");
});
