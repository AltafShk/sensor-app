export interface SensorPayload {
  id: string;
  data: any;
}
