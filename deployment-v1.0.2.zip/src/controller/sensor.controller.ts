import type { RequestHandler } from "express";
import { SensorPayload } from "../typings/sensor.payload";

export abstract class SensorController {
  static handleSignal: RequestHandler<
    unknown,
    unknown,
    SensorPayload,
    unknown
  > = async (req, res) => {
    const { id, data } = req.body;
    console.log(`Received signal from sensor ${id}`);
    return res.status(200).send("OK");
  };
}
